# 🌱 OpenCEA v2.0.0: Commercial Controlled Environment Agriculture Physics Suite

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-2.0.0-emerald.svg)](https://inwoovation.com/suite/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Subsidies](https://img.shields.io/badge/Global_Subsidies-192_Verified_(v7.0)-0ea5e9.svg)](https://inwoovation.com/tools/global-agri-subsidy-grant-navigator.html)

OpenCEA (`v2.0.0`) is an open-source, zero-dependency biophysics and horticultural engineering calculation suite designed for commercial greenhouse operators, vertical farm engineers, agronomists, and CEA researchers.

---

## ⚡ 8 Core Biophysical Calculation Engines (`biophysics_kernel.js` v2.0.0)

1. **Vapor Pressure Deficit (VPD) & Dew-Point Engine (`computeVPD`)**: Calculates leaf and air VPD plus psychrometric dew point using Tetens formulations and transpirational offset kinetics. Classifies agronomical stress boundaries (Guttation risk vs. Stomatal closure).
2. **Daily Light Integral (DLI) Forecaster (`computeDLI`)**: Quantifies cumulative daily photosynthetic photon flux (`mol/m²/day`) across photoperiods and supplemental lighting.
3. **Greenhouse Transmission & Infiltration Heating Model (`computeHeatingLoad`)**: Sizes peak heating networks for Venlo glasshouses based on **DIN V 18599 / NEN 3859** with dynamic thermal screen attenuation.
4. **CO₂ Enrichment & Mass-Balance Dosing Engine (`computeCO2Injection`)**: Computes required mass injection rate (`kg/h` and `g/m²·h`) factoring in structural ventilation leakage (`ACH`) and active canopy photosynthetic assimilation.
5. **Hydroponic Fertigation EC & Dilution Solver (`computeFertigationDilution`)**: Balances stock tank concentration, injector ratios (`1:100`), and target dripper EC (`mS/cm`).
6. **Horticultural LED Efficacy & Sensible Heat Simulator (`computeLEDEfficacy`)**: Translates target PPFD and fixture PPE (`µmol/J`) into connected electrical load (`kW`), sensible heat dissipation (`kW`), and annual `MWh`.
7. **Semi-Closed Greenhouse Mollier $h$–$x$ Latent Heat & Condensate Engine (`computeMollierLatentRecovery` — *New in v2.0.0*)**: Models moist air enthalpy, evaporator coil dehumidification (`L/h` distillate recovery), compressor electrical input, condenser sensible reheat (`kW_th`), and effective thermal `COP_th` for Air Treatment Units (ATUs).
8. **Zero-NaN / Zero-Infinity Input Guard (`readSafeNumber` — *New in v2.0.0*)**: Deterministic numeric input clamping across browser DOM calculators and automated pipelines, plus pure Python CLI (`horti_cli.py`) and single-file HTML5 offline dashboard (`index.html`).

---

## 🚀 Quick Start

### 1. Command-Line Interface (Python CLI)

Run immediately with standard Python 3.9+ (zero external `pip` packages):

```bash
# 1. Calculate Vapor Pressure Deficit (VPD)
python horti_cli.py vpd --temp 24.5 --rh 70.0 --leaf-temp 22.5

# 2. Calculate Daily Light Integral (DLI)
python horti_cli.py dli --ppfd 350 --hours 16

# 3. Estimate Greenhouse Heating Loss (5000 m2 Venlo, 1 screen, -5C outside)
python horti_cli.py heat --area 5000 --tin 18.5 --tout -5.0 --screens 1

# 4. Calculate CO2 Enrichment Mass Injection Rate
python horti_cli.py co2 --area 1000 --height 4.5 --ach 0.5 --target 1000 --ambient 420

# 5. Calculate Fertigation Stock Solution Dosage
python horti_cli.py fert --target-ec 2.2 --base-ec 0.3 --ratio 100 --volume 1000

# 6. Calculate LED Photon Flux & HVAC Heat Rejection
python horti_cli.py led --watts 640 --count 20 --ppe 2.8 --hours 16
```

### 2. Offline Standalone Dashboard & Rule-Based Diagnostic Router

Simply double-click `index.html` or open it in any modern web browser. No web server, Node.js, or internet connection required.

* **Embedded Rule-Based Agronomic Triage & Diagnostic Router**: Translates field symptoms (*"leaves curling and flowers dropping"*, *"winter night humidity condensate"*), syncs the calculation cards live, and outputs 3-step agronomic protocols.
* **1-Click Field Presets**: Instant sizing for VPD stress, peak heating demand, LED photoperiods, fertigation EC balancing, and CO₂ enrichment.

---

## 💶 Paired Global Agricultural Subsidy & CapEx Ecosystem (`192` Verified Grants · v7.0)

OpenCEA `v2.0.0` integrates directly with the **Global 8-Country 3-Tier Agricultural Subsidy Radar (`192` Verified Programs across US, Germany, Netherlands, Japan, South Korea, France, Spain, and Canada)**:

1. **Interactive 192-Grant Navigator (`$0.00` Open Access)**: https://inwoovation.com/tools/global-agri-subsidy-grant-navigator.html
2. **Offline Institutional Workbook**: `Global_8_Country_192_Agri_Subsidy_Master_Playbook_2026.xlsx` (`01_Executive_Summary`, `02_All_192_Verified_Grants`, `03_Application_Playbooks`, `04_Country_Tier_Matrix`).
3. **Standalone Air-Gapped Package** (`OpenCEA-Pro-v1.0.0.zip`, `Kernel v2.0.0`) hosted permanently at https://inwoovation.com/suite/OpenCEA-Pro-v1.0.0.zip.
4. **42 Live Web Engineering Calculators & VenloCAD 3D**: https://inwoovation.com/suite/

👉 **[Explore the Open Source Repository & Digital Vault](https://inwoovation.com/store.html)**

---

## 🛡️ Zero-Paywall & Open Access Guarantee
Precision biophysical and capital-feasibility tools should be accessible to all food producers without paywalls or restrictive licenses. All core tools, algorithms, and calculators remain permanently free (`$0.00`) under MIT & CC-BY 4.0 terms.

---

## ⚖️ Limitation of Agricultural Liability
*OpenCEA provides theoretical thermodynamic and biophysical simulation estimates based on published academic and engineering standards (DIN V 18599, DIN EN 13031-1, ASAE EP411, FAO-56). In no event shall Inwoovation Lab or the authors be held liable for any direct, indirect, incidental, or consequential crop loss, frost/freezing damage, physiological plant stress, equipment failure, or financial damages resulting from the use of this software. All simulation outputs must be independently validated by a licensed professional agronomist or facility engineer before physical implementation.*

---

## 📄 License & Attribution
Distributed 100% Free under MIT Open-Access Terms (`COMMERCIAL_LICENSE.txt`). Maintained by **Inwoovation Engineering Lab**.  
Website: https://inwoovation.com | Live Suite: https://inwoovation.com/suite/ | Inquiries: `contact@inwoovation.com`
